//
//  ViewController.swift
//  FBtest
//
//  Created by robin on 2018-07-19.
//  Copyright © 2018 robin. All rights reserved.
//

import UIKit
import Firebase
import FirebaseDatabase

class ViewController: UIViewController {
    var db:DatabaseReference!

    @IBOutlet weak var textView: UITextField!
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        //TODO: setup your FB variable
    
        self.db = Database.database().reference()
        
        //TELL FIREBASE YOU ARE INTERESTED IN KNOWING
        // WHEN DATA CHANGES!!! (THINGS GET ADDED)
        // - ADDED
        // - DELETED
        // - UPATED
        
        
        /*
        // add something to the database
        self.db.setValue(4576565656)
        
        // add some keys
        let x:[String:Any] = ["age":25, "color":"blue"]
        self.db.setValue(x)
        
        // add a new node
        self.db.child("cars").setValue(55)
        self.db.child("name").setValue("jenelle")
        self.db.child("yyya").setValue("sdfsfds")
        /*
        // add nodes inside another node
        let y:[String:Any] = ["name":"kadeem", "dept":"CPCT"]
        self.db.child("instructors").setValue(y)
        */
 
       
        // create a random id
        self.db.childByAutoId().setValue("apple")
        self.db.childByAutoId().setValue("banana")
        self.db.childByAutoId().setValue("carrot")
        self.db.childByAutoId().setValue("donut")
        self.db.childByAutoId().setValue("roundy")
        */
        watchForChanges()
    }
    
    func watchForChanges() {
        self.db.child("todos").observe(DataEventType.childAdded, with:{(snapshot) in
            print("something was added in the database!!!")
        })
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }

    @IBAction func addTask(_ sender: UIButton) {
        
        print("Add task pressed")
        
        // 1. get the text from the ui
        let x = textView.text!
        
        if(x.isEmpty == true) {
            return
        }
        
        // 2. put the text in firebase
        self.db.child("todos").childByAutoId().setValue(x)
        
        // optional: ui update
        textView.text = ""
    }
    
}

