//
//  ViewController.swift
//  TehNoteBook
//
//  Created by MacStudent on 2018-07-16.
//  Copyright © 2018 MacStudent. All rights reserved.
//

import UIKit
import CoreData // import Core Data

class ViewController: UIViewController {
    
    @IBOutlet weak var txtBookName: UITextField!
    
    @IBOutlet weak var txtPageName: UITextField!
    //create the context variable
    var context:NSManagedObjectContext!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        
        //app delegate
        guard let appDelegate = UIApplication.shared.delegate as? AppDelegate else { return }
        //set the context
        context = appDelegate.persistentContainer.viewContext
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    // MARK: Actions for the app
    @IBAction func btnAddNotebook(_ sender: UIButton) {
        // TODO: Add notebook code goes here
        
        print("Add Button pressed" )
        
        // VALIDATION
        // a) -- check if the textbox is empty
        
        let x = txtBookName.text!
        
        if (x.isEmpty) {
            print("Please give your notebook a name")
            return
        }
        
        let notebook = Notebook(context: context)
        notebook.title = txtBookName.text!
        notebook.dateCreated = Date()
        
        do
        {
            try context.save()
        }
        catch
        {
            print("Error saving notebook to database")
        }
    }
    
    @IBAction func btnAddPage(_ sender: UIButton) {
        let page = Page(context: context)
        page.text = txtPageName.text!
        page.dateAdded = Date()
        
        // get the notebook that you want to add the page to
        let n = getNotebook(notebookName:txtBookName.text!)
        // associate the page to the notebook
        
        page.notebook = n;
        
        do {
            try context.save()
            print("page saved")
        }
            catch  {
                print("error saving page")
            }
            
        
    }
    
    
    func getNotebook(notebookName:String) -> Notebook? {
        // 1. fetch the notebook with this name from CoreData
        // let fetchRequest:NSFetchRequest<__> = ___.fetchRequest()
        
        let fetchRequest:NSFetchRequest<Notebook> = Notebook.fetchRequest()
        
        // 2. add a WHERE to my sql statement
        fetchRequest.predicate = NSPredicate(format: "title = %@", txtBookName.text!)
        
        // 3. add a LIMIT
        fetchRequest.fetchLimit = 1
        
        // fetchRequest = SELECT * from NoteBook WHERE name = 'swift class' LIMIT 1
        
        // 4. Get the results from the database
        
        do {
            let rows = try context.fetch(fetchRequest)
            
            if (rows.count > 0) {
                print(rows[0].title)
                return rows[0]
            }
            else{
                //no notebooks found that have this name
                return nil
            }
        }
        catch {
            print("Error getting from the database")
        }
        
        // 2. Return it
        return nil
    }
    
    @IBAction func btnShowPages(_ sender: UIButton) {
        
        // get name of notebook
        
        // query database
        
        
        
    }
    
    
}

