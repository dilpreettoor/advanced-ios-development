//
//  ViewController.swift
//  UserDefaultApp
//
//  Created by MacStudent on 2018-07-09.
//  Copyright © 2018 MacStudent. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Play with userDefault here
        
        // 1. tell ios you want to use userDefaults (localStorage from web)
        let defaults = UserDefaults.standard
        
        //print(defaults.dictionaryRepresentation())
        
        // 2. add some things to the UserDefaults
        
        //string
        defaults.set("PriteshKumar Patel", forKey:"person");
        
        //boolean
        defaults.set(true, forKey:"isInstructor");
        
        //double
        defaults.set(800.59, forKey:"hourlyRate");
        
        //array
        let coursesTaught = ["ios 101", "android 101", "swift 101", "java 101", "databases"]

        defaults.set(coursesTaught, forKey: "courses")
        
        //dictionary
        let studentDetail = ["name":"Person", "id":"C0165842", "program":"MADT" ]
        defaults.set(studentDetail, forKey: "sDetails")
        
        // 3. print / get stuff from userDefaults
        
        //Get Specific thing from dictionary
        
        let x = defaults.double(forKey: "hourlyRate")
        print(x);
        
        print("Is Pritesh and instructor?")
        print(defaults.bool(forKey: "isInstructor"))
        
        print("What's his full name?")
        let name = defaults.string(forKey: "person")
        print(name!)
        
        //get an array out
        
        print("What courses does he teach?")
        //let c  = defaults.array(forKey: "courses") as! [String]
        //print(c)
        
        // get a dictionary out
       // print("Who is his student")
        //let d = defaults.dictionary(forKey: sDetails) as! Dictionary[
        //print(defaults.dictionaryRepresentation())
        
        
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


}

