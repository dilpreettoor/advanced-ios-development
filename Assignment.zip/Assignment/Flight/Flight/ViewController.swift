//
//  ViewController.swift
//  Flight
//
//  Created by Dilpreet S Toor on 2019-03-14.
//  Copyright © 2019 Dilpreet S Toor. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var txtFrom: UITextField!
    @IBOutlet weak var txtTo: UITextField!
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }

    @IBAction func sendDatatowatch(_ sender: Any) {
    }
    
}

